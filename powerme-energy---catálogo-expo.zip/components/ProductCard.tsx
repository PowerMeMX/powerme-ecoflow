import React from 'react';
import { Product } from '../types';
import { Icon } from './Icon';

interface ProductCardProps {
  product: Product;
  onClick: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  return (
    <div 
      onClick={() => onClick(product)}
      className="group relative bg-[#0a0a0a] border border-white/10 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:border-brand-cyan/50 hover:shadow-[0_0_25px_rgba(0,188,212,0.15)] hover:-translate-y-1 flex flex-col"
    >
      {/* Image Container - Highlighted */}
      <div className="relative aspect-square w-full p-6 bg-gradient-to-b from-white/5 to-transparent flex items-center justify-center overflow-hidden">
        {/* Glow behind image */}
        <div className="absolute inset-0 bg-brand-cyan/5 rounded-full blur-2xl transform scale-50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        
        <img 
          src={product.imagePlaceholder} 
          alt={product.name}
          className="relative z-10 w-full h-full object-contain drop-shadow-xl transform transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Category Pill floating */}
        <div className="absolute top-3 left-3 bg-black/80 backdrop-blur border border-white/10 text-gray-300 text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
          {product.category.replace('Serie ', '')}
        </div>
      </div>
      
      {/* Minimal Info Section */}
      <div className="p-4 flex flex-col items-center text-center bg-[#050505] border-t border-white/5 relative z-20">
        <h3 className="text-lg font-bold text-white mb-1 leading-tight group-hover:text-brand-cyan transition-colors">
          {product.name}
        </h3>
        
        <button className="mt-3 text-xs font-semibold text-brand-cyan flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          Ver detalles <Icon name="arrow-left" className="w-3 h-3 rotate-180" />
        </button>
      </div>
    </div>
  );
};