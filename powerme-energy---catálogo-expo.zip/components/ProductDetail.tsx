import React, { useEffect } from 'react';
import { Product } from '../types';
import { Icon } from './Icon';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack }) => {
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="animate-fade-in-up min-h-screen pb-20 bg-[#050505]">
      
      {/* Sticky Navigation */}
      <div className="sticky top-0 z-50 bg-[#050505]/80 backdrop-blur-lg border-b border-white/10 px-4 py-4 supports-[backdrop-filter]:bg-[#050505]/60">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <button 
            onClick={onBack}
            className="group flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <div className="p-2 rounded-full bg-white/5 group-hover:bg-brand-cyan group-hover:text-black transition-colors">
               <Icon name="arrow-left" className="w-5 h-5" />
            </div>
            <span className="font-semibold text-sm uppercase tracking-wider">Volver</span>
          </button>
          <div className="hidden md:block text-gray-500 text-sm font-mono">
             {product.category}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pt-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Hero Image Section */}
          <div className="lg:col-span-7 relative">
            <div className="sticky top-24">
                {/* Background Glow Effect */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-brand-cyan/20 rounded-full blur-[80px] -z-10"></div>
                
                <div className="aspect-square w-full rounded-3xl overflow-hidden border border-white/10 bg-white/5 relative shadow-2xl ring-1 ring-white/5">
                <img 
                    src={product.imagePlaceholder} 
                    alt={product.name} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 ease-in-out"
                />
                </div>

                {/* Feature Pills under image on mobile, grid on desktop */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    {product.features.map((feature, idx) => (
                        <div key={idx} className="bg-white/5 hover:bg-white/10 transition-colors p-4 rounded-2xl border border-white/5 flex flex-col items-center text-center gap-2 group">
                        <div className="text-gray-400 group-hover:text-brand-cyan transition-colors p-2 rounded-full bg-black/20">
                            <Icon name={feature.icon} className="w-6 h-6" />
                        </div>
                        <span className="text-xs text-gray-300 font-medium leading-tight">{feature.text}</span>
                        </div>
                    ))}
                </div>
            </div>
          </div>

          {/* Info Section */}
          <div className="lg:col-span-5 flex flex-col justify-start space-y-8">
            <div>
                <div className="inline-block px-3 py-1 mb-4 rounded border border-brand-cyan/30 bg-brand-cyan/10 text-brand-cyan text-xs font-bold uppercase tracking-widest">
                    Especificaciones Pro
                </div>
                <h1 className="text-5xl md:text-6xl font-black text-white leading-none mb-4 tracking-tight">
                    {product.name}
                </h1>
                <p className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-gray-200 to-gray-500 font-light leading-snug">
                    {product.tagline}
                </p>
            </div>
            
            <div className="prose prose-invert max-w-none">
              <p className="text-gray-400 text-lg leading-relaxed">{product.description}</p>
            </div>

            {/* Tech Specs Table */}
            <div className="glass-panel rounded-3xl p-8 shadow-xl">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
                <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-brand-cyan text-black">
                    <Icon name="bolt" className="w-5 h-5" />
                </span>
                Ficha Técnica
              </h3>
              <div className="space-y-5">
                {product.specs.map((spec, idx) => (
                  <div key={idx} className="flex items-center justify-between border-b border-dashed border-gray-700 pb-2 last:border-0 last:pb-0">
                    <span className="text-gray-500 font-medium text-sm uppercase tracking-wide">{spec.label}</span>
                    <span className="text-white font-bold text-lg text-right">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA Box */}
            <div className="relative overflow-hidden p-6 rounded-2xl border border-brand-cyan/50 bg-brand-cyan/5 text-center group">
               <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-brand-cyan/20 rounded-full blur-xl group-hover:bg-brand-cyan/30 transition-colors"></div>
              <p className="relative z-10 text-brand-cyan font-bold text-xl mb-1">
                ¿Lo quieres ver en acción?
              </p>
              <p className="relative z-10 text-sm text-gray-400">
                Acércate a nuestro mostrador y pide una demostración en vivo.
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};